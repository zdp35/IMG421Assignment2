# Apple Picker (2D) — Three Creative Difficulties + Menu (Unity 2022.3 LTS)

## What this project includes
- **MainMenu** scene with Easy / Medium / Hard selection
- **Game** scene is **endless**: you play until you lose all lives
- Win/Lose requirement met via **Game Over** overlay + buttons:
  - **Play Again**
  - **Main Menu**
- **Lives counter** (not visual baskets) + Score counter
- **2D sprites** (generated at runtime; no art files required)

## Difficulty designs (not spawn-rate changes)
- **Easy**: Magnet catch (normal apples) + lose 1 life per **3 misses** + wider basket
- **Medium**: Wind columns push falling apples sideways
- **Hard**: Bomb apples cost a life + Rotten apples reduce score + 2 consecutive misses freeze basket + basket shrinks on misses

Spawn timing is intentionally constant across modes to avoid the "non-creative spawn-rate change" approach.

## Unity version
Targeted for **Unity 2022.3 LTS**.

## Scenes
- `Assets/Scenes/MainMenu.unity`
- `Assets/Scenes/Game.unity`

## Build setup
1. Open `MainMenu` scene
2. File → Build Settings → Add Open Scenes (add both scenes)
3. Ensure `MainMenu` is Scene 0
4. Play or Build (WebGL)

## Controls
- Basket: mouse X or Arrow Keys / A-D
