public static class RuntimeTuning
{
    // Horizontal clamp for basket movement (half-width in world units).
    // BasketMover2D reads this each frame.
    public static float BasketClamp = 8.5f;

    // Minimum clamp so the game remains playable.
    public static float MinClamp = 0.6f;
}
