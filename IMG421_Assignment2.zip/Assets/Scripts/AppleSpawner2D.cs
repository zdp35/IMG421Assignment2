using UnityEngine;

public class AppleSpawner2D : MonoBehaviour
{
    public GameState state;
    public DifficultyConfig cfg;
    public float spawnY = 5.5f;

    private float _spawnTimer;
    private float _x;
    private float _xDir = 1f;

    private void Start()
    {
        _spawnTimer = cfg.SpawnInterval;
        transform.position = new Vector3(0, spawnY, 0);
    }

    private void Update()
    {
        // Move spawner left/right
        _x += _xDir * cfg.SpawnerSpeed * Time.deltaTime;

        if (_x > cfg.SpawnerBounds)
        {
            _x = cfg.SpawnerBounds;
            _xDir = -1f;
        }
        if (_x < -cfg.SpawnerBounds)
        {
            _x = -cfg.SpawnerBounds;
            _xDir = 1f;
        }

        transform.position = new Vector3(_x, spawnY, 0);

        // Spawn logic
        _spawnTimer -= Time.deltaTime;
        if (_spawnTimer <= 0f)
        {
            Spawn();
            _spawnTimer = Mathf.Max(0.05f, cfg.SpawnInterval + Random.Range(-cfg.SpawnJitter, cfg.SpawnJitter));
        }
    }

    private void Spawn()
    {
        var go = new GameObject("Orb");
        go.transform.position = transform.position;

        var a = go.AddComponent<Apple2D>();
        a.Init(state, ChooseType());

        ApplyWildImpulse(go);
    }

    private void ApplyWildImpulse(GameObject go)
    {
        if (GameSettings.Difficulty != Difficulty.Expert) return;

        var rb = go.GetComponent<Rigidbody2D>();
        if (rb == null) return;

        float vx = Random.Range(-6.5f, 6.5f);
        rb.velocity = new Vector2(vx, rb.velocity.y);
        rb.angularVelocity = Random.Range(-420f, 420f);
    }

    private AppleType ChooseType()
    {
        if (cfg.BombsEnabled && Random.value < cfg.BombChance)
            return AppleType.Bomb;

        if (cfg.RottenEnabled && Random.value < cfg.RottenChance)
            return AppleType.Rotten;

        return AppleType.Normal;
    }
}
