using UnityEngine;

public class MissZone2D : MonoBehaviour
{
    public GameState state;

    private void OnTriggerEnter2D(Collider2D other)
    {
        var apple = other.GetComponent<Apple2D>();
        if (apple == null) return;

        if (apple.type == AppleType.Normal)
        {
            state.RegisterMiss();
        }
        Destroy(other.gameObject);
    }
}
