using UnityEngine;
using UnityEngine.UI;

public class UIHud2D : MonoBehaviour
{
    public GameState state;

    public Text headerText;

    public GameObject overlayRoot;
    public Text overlaySubtitle;

    public string difficultyName = "";

    private void Start()
    {
        if (state != null)
        {
            state.OnChanged += Refresh;
            Refresh();
        }
    }

    private void OnDestroy()
    {
        if (state != null) state.OnChanged -= Refresh;
    }

    private void Refresh()
    {
        if (headerText != null)
        {
            headerText.text =
                $"Difficulty: {difficultyName}\n" +
                $"Score: {state.Score}    Lives: {state.Lives}\n" +
                $"Endless: survive as long as possible.";
        }

        if (state.IsGameOver)
        {
            Time.timeScale = 0f;
            if (overlayRoot != null) overlayRoot.SetActive(true);
            if (overlaySubtitle != null) overlaySubtitle.text = state.EndReason;
        }
    }
}
