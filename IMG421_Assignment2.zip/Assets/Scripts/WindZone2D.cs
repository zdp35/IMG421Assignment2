using UnityEngine;

public class WindZone2D : MonoBehaviour
{
    public float strength = 18f;
    public float chaos = 0f;

    private void OnTriggerStay2D(Collider2D other)
    {
        var rb = other.attachedRigidbody;
        if (rb == null) return;
        if (other.GetComponent<Apple2D>() == null) return;

        float s = strength + (chaos > 0f ? Random.Range(-chaos, chaos) : 0f);
        rb.AddForce(new Vector2(s, 0f), ForceMode2D.Force);
    }
}
