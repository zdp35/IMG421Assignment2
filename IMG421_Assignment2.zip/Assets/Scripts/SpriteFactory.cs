using UnityEngine;

public static class SpriteFactory
{
    // Make a transparent texture
    private static Texture2D Tex(int w, int h)
    {
        var t = new Texture2D(w, h, TextureFormat.RGBA32, false);
        t.filterMode = FilterMode.Point;
        t.wrapMode = TextureWrapMode.Clamp;
        return t;
    }

    public static Sprite CircleSprite(Color fill, Color outline, int px = 96, int outlinePx = 3)
    {
        var tex = Tex(px, px);
        var cFill = (Color32)fill;
        var cOut = (Color32)outline;
        var clear = new Color32(0,0,0,0);

        float r = (px * 0.5f) - 1f;
        float r2 = r * r;
        float ro = Mathf.Max(0, r - outlinePx);
        float ro2 = ro * ro;

        for (int y = 0; y < px; y++)
        for (int x = 0; x < px; x++)
        {
            float dx = x - (px * 0.5f);
            float dy = y - (px * 0.5f);
            float d2 = dx*dx + dy*dy;
            if (d2 <= r2 && d2 >= ro2) tex.SetPixel(x, y, cOut);
            else if (d2 < ro2) tex.SetPixel(x, y, cFill);
            else tex.SetPixel(x, y, clear);
        }

        // tiny highlight
        for (int y = (int)(px*0.62f); y < (int)(px*0.78f); y++)
        for (int x = (int)(px*0.62f); x < (int)(px*0.78f); x++)
        {
            var col = tex.GetPixel(x, y);
            if (col.a > 0.1f)
                tex.SetPixel(x, y, Color.Lerp(col, Color.white, 0.25f));
        }

        tex.Apply();
        return Sprite.Create(tex, new Rect(0, 0, px, px), new Vector2(0.5f, 0.5f), pixelsPerUnit: 64);
    }

    public static Sprite RoundedRectSprite(Color fill, Color outline, int w = 256, int h = 96, int r = 18, int outlinePx = 3)
    {
        var tex = Tex(w, h);
        var clear = new Color32(0,0,0,0);
        var cf = (Color32)fill;
        var co = (Color32)outline;

        for (int y = 0; y < h; y++)
        for (int x = 0; x < w; x++)
        {
            bool inside = InsideRounded(x, y, w, h, r);
            bool insideInner = InsideRounded(x, y, w, h, Mathf.Max(0, r - outlinePx));
            if (!inside) tex.SetPixel(x, y, clear);
            else if (!insideInner) tex.SetPixel(x, y, co);
            else tex.SetPixel(x, y, cf);
        }

        tex.Apply();
        return Sprite.Create(tex, new Rect(0, 0, w, h), new Vector2(0.5f, 0.5f), pixelsPerUnit: 64);
    }

    private static bool InsideRounded(int x, int y, int w, int h, int r)
    {
        // core rect
        if (x >= r && x < w - r && y >= 0 && y < h) return true;
        if (x >= 0 && x < w && y >= r && y < h - r) return true;

        // corners
        int cx = x < r ? r : (x >= w - r ? w - r - 1 : x);
        int cy = y < r ? r : (y >= h - r ? h - r - 1 : y);

        int dx = x - cx;
        int dy = y - cy;
        return (dx*dx + dy*dy) <= (r*r);
    }

    public static Sprite TreeSprite(int px = 256)
    {
        var tex = Tex(px, px);
        var clear = new Color32(0,0,0,0);

        // background transparent
        for (int i = 0; i < px * px; i++) tex.SetPixel(i % px, i / px, clear);

        // trunk
        var trunk = new Color(0.35f, 0.22f, 0.12f, 1f);
        int trunkW = (int)(px * 0.16f);
        int trunkH = (int)(px * 0.35f);
        int trunkX0 = (px - trunkW) / 2;
        int trunkY0 = (int)(px * 0.05f);

        for (int y = trunkY0; y < trunkY0 + trunkH; y++)
        for (int x = trunkX0; x < trunkX0 + trunkW; x++)
            tex.SetPixel(x, y, trunk);

        // canopy blobs
        var leaf1 = new Color(0.10f, 0.55f, 0.18f, 1f);
        var leaf2 = new Color(0.12f, 0.62f, 0.20f, 1f);
        DrawBlob(tex, px, new Vector2(px*0.50f, px*0.60f), px*0.32f, leaf1);
        DrawBlob(tex, px, new Vector2(px*0.36f, px*0.56f), px*0.24f, leaf2);
        DrawBlob(tex, px, new Vector2(px*0.64f, px*0.56f), px*0.24f, leaf2);
        DrawBlob(tex, px, new Vector2(px*0.50f, px*0.72f), px*0.26f, leaf2);

        // subtle outline
        var outline = new Color(0.05f, 0.20f, 0.08f, 1f);
        OutlineAlpha(tex, px, outline);

        tex.Apply();
        return Sprite.Create(tex, new Rect(0, 0, px, px), new Vector2(0.5f, 0.0f), pixelsPerUnit: 64);
    }

    private static void DrawBlob(Texture2D tex, int px, Vector2 center, float radius, Color col)
    {
        float r2 = radius * radius;
        for (int y = 0; y < px; y++)
        for (int x = 0; x < px; x++)
        {
            float dx = x - center.x;
            float dy = y - center.y;
            float d2 = dx*dx + dy*dy;
            if (d2 <= r2)
            {
                // preserve trunk pixels
                var existing = tex.GetPixel(x, y);
                if (existing.a > 0.1f && existing.g < 0.3f) continue;
                tex.SetPixel(x, y, col);
            }
        }
    }

    private static void OutlineAlpha(Texture2D tex, int px, Color outline)
    {
        // 1px outline where transparent neighbors opaque
        for (int y = 1; y < px-1; y++)
        for (int x = 1; x < px-1; x++)
        {
            var c = tex.GetPixel(x, y);
            if (c.a > 0.1f) continue;

            bool near = false;
            for (int oy = -1; oy <= 1 && !near; oy++)
            for (int ox = -1; ox <= 1 && !near; ox++)
                if (tex.GetPixel(x+ox, y+oy).a > 0.1f) near = true;

            if (near) tex.SetPixel(x, y, outline);
        }
    }

    public static Sprite VerticalGradient(Color top, Color bottom, int w = 32, int h = 512)
    {
        var tex = Tex(w, h);
        for (int y = 0; y < h; y++)
        {
            float t = (float)y / (h - 1);
            var c = Color.Lerp(bottom, top, t);
            for (int x = 0; x < w; x++) tex.SetPixel(x, y, c);
        }
        tex.Apply();
        return Sprite.Create(tex, new Rect(0,0,w,h), new Vector2(0.5f, 0.5f), pixelsPerUnit: 64);
    }
}
