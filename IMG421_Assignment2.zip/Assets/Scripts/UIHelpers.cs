using UnityEngine;
using UnityEngine.UI;

public static class UIHelpers
{
    public static Canvas CreateCanvas(string name = "Canvas")
    {
        var go = new GameObject(name);

        var canvas = go.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvas.sortingOrder = 100;

        var scaler = go.AddComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920, 1080);
        scaler.matchWidthOrHeight = 0.5f;

        go.AddComponent<GraphicRaycaster>();

        return canvas;
    }

    // Backward-compatible overload used across project
    public static GameObject CreatePanel(Transform parent, Vector2 size)
    {
        var panel = new GameObject("Panel");
        panel.transform.SetParent(parent, false);

        var img = panel.AddComponent<Image>();
        img.color = new Color(0.05f, 0.05f, 0.08f, 0.85f);

        var rt = panel.GetComponent<RectTransform>();
        rt.sizeDelta = size;
        rt.anchorMin = new Vector2(0.5f, 0.5f);
        rt.anchorMax = new Vector2(0.5f, 0.5f);
        rt.pivot = new Vector2(0.5f, 0.5f);
        rt.anchoredPosition = Vector2.zero;

        return panel;
    }

    // Explicit anchor overload (optional use)
    public static GameObject CreatePanel(Transform parent, Vector2 size, Vector2 anchorMin, Vector2 anchorMax, Vector2 anchoredPos)
    {
        var panel = CreatePanel(parent, size);
        var rt = panel.GetComponent<RectTransform>();
        rt.anchorMin = anchorMin;
        rt.anchorMax = anchorMax;
        rt.anchoredPosition = anchoredPos;
        return panel;
    }

    public static Text CreateText(Transform parent, string text, int fontSize, TextAnchor anchor)
    {
        var go = new GameObject("Text");
        go.transform.SetParent(parent, false);

        var txt = go.AddComponent<Text>();
        txt.text = text;
        txt.fontSize = fontSize;
        txt.alignment = anchor;
        txt.color = Color.white;
        txt.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        txt.horizontalOverflow = HorizontalWrapMode.Overflow;
        txt.verticalOverflow = VerticalWrapMode.Overflow;

        var rt = txt.GetComponent<RectTransform>();
        rt.sizeDelta = new Vector2(600, 200);

        return txt;
    }

    public static Button CreateButton(Transform parent, string label, Vector2 size)
    {
        var go = new GameObject("Button");
        go.transform.SetParent(parent, false);

        var img = go.AddComponent<Image>();
        img.color = new Color(0.12f, 0.02f, 0.25f, 0.95f);

        var btn = go.AddComponent<Button>();

        var rt = go.GetComponent<RectTransform>();
        rt.sizeDelta = size;
        rt.anchorMin = new Vector2(0.5f, 0.5f);
        rt.anchorMax = new Vector2(0.5f, 0.5f);
        rt.pivot = new Vector2(0.5f, 0.5f);

        // Label
        var t = CreateText(go.transform, label, 24, TextAnchor.MiddleCenter);
        t.rectTransform.anchorMin = Vector2.zero;
        t.rectTransform.anchorMax = Vector2.one;
        t.rectTransform.offsetMin = new Vector2(16, 10);
        t.rectTransform.offsetMax = new Vector2(-16, -10);
        t.color = new Color(0.92f, 0.92f, 1f, 1f);

        // Simple hover tint
        var colors = btn.colors;
        colors.highlightedColor = new Color(0.18f, 0.05f, 0.38f, 1f);
        colors.pressedColor = new Color(0.10f, 0.02f, 0.22f, 1f);
        colors.selectedColor = colors.highlightedColor;
        btn.colors = colors;

        return btn;
    }

    // Helper used throughout for quick positioning
    public static void Place(RectTransform rt, float anchorX, float anchorY, float width, float height, Vector2 offset = default)
    {
        rt.anchorMin = new Vector2(anchorX, anchorY);
        rt.anchorMax = new Vector2(anchorX, anchorY);
        rt.pivot = new Vector2(anchorX, anchorY);
        rt.sizeDelta = new Vector2(width, height);
        rt.anchoredPosition = offset;
    }
}
