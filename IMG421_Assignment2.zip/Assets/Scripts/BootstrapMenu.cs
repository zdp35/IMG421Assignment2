using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class BootstrapMenu : MonoBehaviour
{
    private void Awake()
    {
        Application.targetFrameRate = 60;
        EnsureEventSystem();
        EnsureCameraAndBackdrop();
        BuildUI();
    }

    private void EnsureEventSystem()
    {
        var es = FindObjectOfType<UnityEngine.EventSystems.EventSystem>();
        if (es != null) return;

        var go = new GameObject("EventSystem");
        go.AddComponent<UnityEngine.EventSystems.EventSystem>();
        go.AddComponent<UnityEngine.EventSystems.StandaloneInputModule>();
        DontDestroyOnLoad(go);
    }

    private void EnsureCameraAndBackdrop()
    {
        if (Camera.main == null)
        {
            var camGo = new GameObject("Main Camera");
            camGo.tag = "MainCamera";
            var cam = camGo.AddComponent<Camera>();
        camGo.AddComponent<AudioListener>();
            cam.orthographic = true;
            cam.orthographicSize = 11.0f;
            cam.backgroundColor = new Color(0.06f, 0.07f, 0.10f, 1f);
            cam.transform.position = new Vector3(0, 0, -10);
        }

        // Backdrop sprite (behind UI)
        var bg = new GameObject("MenuBackdrop");
        bg.transform.position = new Vector3(0, 0, 5);
        var sr = bg.AddComponent<SpriteRenderer>();
        sr.sprite = SpriteFactory.VerticalGradient(new Color(0.10f, 0.13f, 0.18f), new Color(0.04f, 0.05f, 0.08f), 32, 512);
        sr.drawMode = SpriteDrawMode.Sliced;
        sr.size = new Vector2(48, 30);

        // Decorative tree silhouette
        var tree = new GameObject("MenuTree");
        tree.transform.position = new Vector3(0, -1.6f, 0);
        var tr = tree.AddComponent<SpriteRenderer>();
        tr.sprite = ArcaneFactory.RunicTreeSprite();
        tree.transform.localScale = new Vector3(1.05f, 1.05f, 1f);
    }

    private void BuildUI()
    {
        var canvas = UIHelpers.CreateCanvas("MenuCanvas");

        var title = UIHelpers.CreateText(canvas.transform, "Spell Catcher: Arcane Fracture", 60, TextAnchor.MiddleCenter);
        UIHelpers.Place(title.rectTransform, 0.5f, 0.86f, 900, 120);
        title.rectTransform.pivot = new Vector2(0.5f, 0.5f);

        var subtitle = UIHelpers.CreateText(canvas.transform, "Choose Ritual Intensity", 24, TextAnchor.MiddleCenter);
        UIHelpers.Place(subtitle.rectTransform, 0.5f, 0.76f, 900, 60);

        var panel = UIHelpers.CreatePanel(canvas.transform, new Vector2(680, 520));
        UIHelpers.Place(panel.GetComponent<RectTransform>(), 0.5f, 0.50f, 640, 420);

        float y = 170f;

        var easy = UIHelpers.CreateButton(panel.transform, "Apprentice — Guiding Sigil", new Vector2(520, 70));
        easy.GetComponent<RectTransform>().anchoredPosition = new Vector2(0, y);
        easy.onClick.AddListener(() => { GameSettings.Difficulty = Difficulty.Easy; SceneManager.LoadScene("Game"); });

        y -= 100f;
        var med = UIHelpers.CreateButton(panel.transform, "Adept — Mana Surges", new Vector2(520, 70));
        med.GetComponent<RectTransform>().anchoredPosition = new Vector2(0, y);
        med.onClick.AddListener(() => { GameSettings.Difficulty = Difficulty.Medium; SceneManager.LoadScene("Game"); });

        y -= 100f;
        var hard = UIHelpers.CreateButton(panel.transform, "Archmage — Void Backlash", new Vector2(520, 70));
        hard.GetComponent<RectTransform>().anchoredPosition = new Vector2(0, y);
        hard.onClick.AddListener(() => { GameSettings.Difficulty = Difficulty.Hard; SceneManager.LoadScene("Game"); });

        y -= 100f;
        var expert = UIHelpers.CreateButton(panel.transform, "Eldritch — Surges + Wild Orbs", new Vector2(520, 70));
        expert.GetComponent<RectTransform>().anchoredPosition = new Vector2(0, y);
        expert.onClick.AddListener(() => { GameSettings.Difficulty = Difficulty.Expert; SceneManager.LoadScene("Game"); });

        var note = UIHelpers.CreateText(canvas.transform,
            "Controls: Mouse X or Arrow Keys / A-D\nEndless: survive until you lose all lives.",
            18, TextAnchor.UpperCenter);
        UIHelpers.Place(note.rectTransform, 0.5f, 0.08f, 1100, 120);
    }
}
