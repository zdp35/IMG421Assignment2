
using UnityEngine;

public static class ArcaneFactory
{
    private static Texture2D Tex(int w, int h)
    {
        var t = new Texture2D(w, h, TextureFormat.RGBA32, false);
        t.filterMode = FilterMode.Point;
        t.wrapMode = TextureWrapMode.Clamp;
        return t;
    }

    public static Sprite ArcaneOrb(Color core, Color glow, float pulseOffset)
    {
        int px = 128;
        var tex = Tex(px, px);
        var clear = new Color(0,0,0,0);

        float r = px * 0.45f;
        float inner = r * 0.65f;
        float r2 = r*r;
        float inner2 = inner*inner;

        for (int y=0; y<px; y++)
        for (int x=0; x<px; x++)
        {
            float dx = x - px/2f;
            float dy = y - px/2f;
            float d2 = dx*dx + dy*dy;

            if (d2 < inner2) tex.SetPixel(x,y, core);
            else if (d2 < r2) tex.SetPixel(x,y, glow);
            else tex.SetPixel(x,y, clear);
        }

        // small highlight
        for (int y=(int)(px*0.62f); y<(int)(px*0.80f); y++)
        for (int x=(int)(px*0.60f); x<(int)(px*0.78f); x++)
        {
            var c = tex.GetPixel(x,y);
            if (c.a > 0.1f) tex.SetPixel(x,y, Color.Lerp(c, Color.white, 0.18f));
        }

        tex.Apply();
        return Sprite.Create(tex, new Rect(0,0,px,px), new Vector2(0.5f,0.5f), 64);
    }

    public static Sprite RunicTreeSprite()
    {
        int w = 512;
        int h = 640;
        var tex = Tex(w, h);

        var clear = new Color(0,0,0,0);
        var bark = new Color(0.07f,0.07f,0.10f,1f);
        var bark2 = new Color(0.10f,0.10f,0.14f,1f);
        var edge = new Color(0.22f,0.22f,0.28f,1f);

        var glow = new Color(0.48f,0.18f,0.98f,1f);
        var glow2 = new Color(0.20f,0.06f,0.50f,1f);

        // clear
        for (int i=0;i<w*h;i++) tex.SetPixel(i%w, i/w, clear);

        int cx = w/2;

        // Utility: draw filled circle alpha-blended
        void Put(int x, int y, Color c)
        {
            if (x<0||x>=w||y<0||y>=h) return;
            var e = tex.GetPixel(x,y);
            if (e.a < 0.05f) tex.SetPixel(x,y,c);
            else tex.SetPixel(x,y, Color.Lerp(e, c, 0.55f));
        }

        // Trunk (tapered, textured)
        for (int y=24; y<h; y++)
        {
            float ny = (float)(y-24) / (h-24);
            float sway = Mathf.Sin(ny*7.5f) * 10f;
            float half = Mathf.Lerp(84f, 18f, ny);
            int x0 = Mathf.RoundToInt(cx + sway - half);
            int x1 = Mathf.RoundToInt(cx + sway + half);

            for (int x=x0; x<=x1; x++)
            {
                bool border = (x==x0 || x==x1);
                // subtle banding noise
                float n = Mathf.Sin((x*0.07f)+(y*0.09f))*0.5f + 0.5f;
                var body = Color.Lerp(bark, bark2, n);
                tex.SetPixel(x,y, border ? edge : body);
            }
        }

        // Branch stroke
        void Branch(float startY, float dir, float len, float thick, float curl)
        {
            float y = startY;
            float x = cx;
            for (int i=0;i<(int)len;i++)
            {
                float t = i/len;
                float yy = y + i*1.1f;
                float xx = x + dir*(t*t)*150f + Mathf.Sin(t*curl)*18f*(1f-t);

                for (int oy=-6; oy<=6; oy++)
                for (int ox=-6; ox<=6; ox++)
                {
                    float d = ox*ox + oy*oy;
                    if (d > thick*thick) continue;
                    int px = Mathf.RoundToInt(xx+ox);
                    int py = Mathf.RoundToInt(yy+oy);
                    if (px<0||px>=w||py<0||py>=h) continue;

                    var existing = tex.GetPixel(px,py);
                    if (existing.a < 0.1f) continue; // only draw on trunk/branch areas
                    bool b = d > (thick*thick*0.55f);
                    tex.SetPixel(px,py, b ? edge : bark2);
                }
            }
        }

        // Multiple branches for complexity
        Branch(h*0.38f, -1f, 190, 7.2f, 10f);
        Branch(h*0.42f,  1f, 200, 7.2f, 10f);
        Branch(h*0.52f, -1f, 160, 6.2f, 12f);
        Branch(h*0.56f,  1f, 170, 6.2f, 12f);
        Branch(h*0.64f, -1f, 120, 5.2f, 14f);
        Branch(h*0.68f,  1f, 110, 5.0f, 14f);

        // Rune lattice: carve glowing glyphs along trunk
        void GlowDot(int x, int y, float r)
        {
            int rr = Mathf.CeilToInt(r);
            for (int oy=-rr; oy<=rr; oy++)
            for (int ox=-rr; ox<=rr; ox++)
            {
                float d2 = ox*ox + oy*oy;
                if (d2 > r*r) continue;
                float k = 1f - (d2/(r*r));
                Put(x+ox, y+oy, Color.Lerp(glow2, glow, 0.6f*k));
            }
        }

        void GlowLine(int x0,int y0,int x1,int y1)
        {
            int steps = Mathf.Max(Mathf.Abs(x1-x0), Mathf.Abs(y1-y0));
            for(int i=0;i<=steps;i++)
            {
                float t = steps==0?0:(float)i/steps;
                int x = Mathf.RoundToInt(Mathf.Lerp(x0,x1,t));
                int y = Mathf.RoundToInt(Mathf.Lerp(y0,y1,t));
                GlowDot(x,y, 2.2f);
            }
        }

        // Several rune "columns"
        for (int i=0;i<9;i++)
        {
            int y0 = (int)(h*0.18f) + i*52;
            GlowLine(cx-16, y0, cx-16, y0+28);
            GlowLine(cx+16, y0+10, cx+16, y0+40);
            GlowLine(cx, y0+6, cx, y0+44);

            // cross strokes
            GlowLine(cx-26, y0+18, cx-6, y0+28);
            GlowLine(cx+6, y0+24, cx+26, y0+34);
        }

        // Runic "canopy" filigree: a crown of symbols near top
        for (int i=0;i<2200;i++)
        {
            int x = Random.Range(0,w);
            int y = Random.Range((int)(h*0.72f), h-8);
            var basec = tex.GetPixel(x,y);
            if (basec.a < 0.1f) continue;

            // tiny rune sparks
            if (Random.value < 0.45f) GlowDot(x, y, 1.6f);
            else GlowDot(x, y, 1.1f);
        }

        tex.Apply();
        return Sprite.Create(tex, new Rect(0,0,w,h), new Vector2(0.5f,0f), 64);
    }

    public static Sprite SpellCircle()
    {
        int w=256, h=96;
        var tex=Tex(w,h);
        var clear=new Color(0,0,0,0);
        var fill=new Color(0.12f,0.02f,0.25f,1f);
        var edge=new Color(0.4f,0.1f,0.8f,1f);

        for(int y=0;y<h;y++)
        for(int x=0;x<w;x++)
        {
            if(y<4||y>h-5||x<4||x>w-5)
                tex.SetPixel(x,y,edge);
            else tex.SetPixel(x,y,fill);
        }

        tex.Apply();
        return Sprite.Create(tex,new Rect(0,0,w,h),new Vector2(0.5f,0.5f),64);
    }
}
