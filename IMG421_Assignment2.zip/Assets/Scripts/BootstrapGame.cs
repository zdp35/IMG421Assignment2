using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class BootstrapGame : MonoBehaviour
{
    private DifficultyConfig _cfg;
    private GameState _state;

    private void Awake()
    {
        Application.targetFrameRate = 60;

        _cfg = GameSettings.GetConfig();
        _state = new GameState(lives: 3, missesPerLife: _cfg.MissesPerLife, shrinkOnMiss: _cfg.ShrinkBasketOnMiss);

        RuntimeTuning.BasketClamp = 8.5f;

        EnsureEventSystem();
        BuildWorld();
        BuildUI();
    }

    private void EnsureEventSystem()
    {
        var es = FindObjectOfType<UnityEngine.EventSystems.EventSystem>();
        if (es != null) return;

        var go = new GameObject("EventSystem");
        go.AddComponent<UnityEngine.EventSystems.EventSystem>();
        go.AddComponent<UnityEngine.EventSystems.StandaloneInputModule>();
        DontDestroyOnLoad(go);
    }

    private void BuildWorld()
    {
        // Camera
        var camGo = new GameObject("Main Camera");
        var cam = camGo.AddComponent<Camera>();
        camGo.AddComponent<AudioListener>();
        camGo.tag = "MainCamera";
        cam.orthographic = true;
        cam.orthographicSize = 11.0f;
        cam.backgroundColor = new Color(0.03f, 0.02f, 0.06f, 1f);
        cam.transform.position = new Vector3(0, 0, -10);
// Background (gradient)
        var bg = new GameObject("Background");
        bg.transform.position = new Vector3(0, 0, 5);
        var bgSr = bg.AddComponent<SpriteRenderer>();
        bgSr.sortingOrder = -10;
        bgSr.sprite = SpriteFactory.VerticalGradient(new Color(0.10f, 0.13f, 0.18f), new Color(0.05f, 0.06f, 0.09f), 32, 512);
        bgSr.drawMode = SpriteDrawMode.Sliced;
        bgSr.size = new Vector2(48, 30);

        // Tree
        var tree = new GameObject("Tree");
        tree.transform.position = new Vector3(0, 0.6f, 0);
        var treeSr = tree.AddComponent<SpriteRenderer>();
        treeSr.sortingOrder = 0;
        treeSr.sprite = ArcaneFactory.RunicTreeSprite();
        tree.transform.localScale = new Vector3(1.25f, 1.25f, 1f);

// Basket (2D sprite)
        var basket = new GameObject("Basket");
        basket.transform.position = new Vector3(0, -4.4f, 0);

        var sr = basket.AddComponent<SpriteRenderer>();
        sr.sortingOrder = 5;
        basket.AddComponent<BasketSFX>();
                sr.sprite = ArcaneFactory.SpellCircle();
        basket.transform.localScale = new Vector3(_cfg.BasketWidth * 0.55f, 0.42f, 1f);

        // Setup basket collider to match visual and avoid tunneling at high fall speeds
        var box = basket.GetComponent<BoxCollider2D>();
        if (box == null) box = basket.AddComponent<BoxCollider2D>();
        box.isTrigger = false;
        // Size based on sprite bounds (in local units) with padding
        var spr = basket.GetComponent<SpriteRenderer>();
        if (spr != null && spr.sprite != null)
        {
            var b = spr.sprite.bounds;
            box.size = new Vector2(b.size.x * 0.95f, b.size.y * 0.70f);
            box.offset = new Vector2(0f, 0f);
        }
        else
        {
            box.size = new Vector2(2.2f, 0.6f);
            box.offset = Vector2.zero;
        }


        var col = basket.AddComponent<BoxCollider2D>();
        col.isTrigger = false;

        var rb = basket.AddComponent<Rigidbody2D>();
        rb.bodyType = RigidbodyType2D.Kinematic;

        var mover = basket.AddComponent<BasketMover2D>();
        mover.speed = _cfg.BasketSpeed;

        if (_cfg.MagnetCatch)
        {
            var magnet = basket.AddComponent<BasketMagnet2D>();
            magnet.radius = _cfg.MagnetRadius;
            magnet.state = _state;
        }

        // Miss line
        var missZone = new GameObject("MissZone");
        missZone.transform.position = new Vector3(0, -6.1f, 0);
        var mzCol = missZone.AddComponent<BoxCollider2D>();
        mzCol.isTrigger = true;
        mzCol.size = new Vector2(60f, 2.0f);
        var mz = missZone.AddComponent<MissZone2D>();
        mz.state = _state;
        Apple2D.MissY = missZone.transform.position.y - 0.3f;

        // Spawner
        
        // Compute spawn height at the top of the sigil-tree
        float spawnY = 5.3f;
        var treeRenderer = tree.GetComponent<SpriteRenderer>();
        if (treeRenderer != null && treeRenderer.sprite != null)
        {
            // bounds are in world units after scaling
            spawnY = treeRenderer.bounds.max.y + 0.2f;
        }

var spawnerGo = new GameObject("AppleSpawner");
        var spawner = spawnerGo.AddComponent<AppleSpawner2D>();
        spawner.spawnY = spawnY;
        spawner.state = _state;
        spawner.cfg = _cfg;

        // Wind columns for Medium (2D trigger strips)
        if (_cfg.WindEnabled)
        {
            CreateWindColumn("WindLeft",  -4.5f, -_cfg.WindStrength);
            CreateWindColumn("WindRight",  4.5f,  _cfg.WindStrength);
            CreateWindColumn("WindCenter", 0.0f,  -_cfg.WindStrength * 0.7f);
        }
    }

    private void CreateWindColumn(string name, float x, float strength)
    {
        var go = new GameObject(name);
        go.transform.position = new Vector3(x, 0.0f, 0);

        var col = go.AddComponent<BoxCollider2D>();
        col.isTrigger = true;
        col.size = new Vector2(2.0f, 14.0f);

        var wz = go.AddComponent<WindZone2D>();
        wz.strength = strength;
    }

    private void BuildUI()
    {
        var canvas = UIHelpers.CreateCanvas("GameCanvas");

        var hudPanel = UIHelpers.CreatePanel(canvas.transform, new Vector2(520, 120));
        var hudRt = hudPanel.GetComponent<RectTransform>();
        hudRt.anchorMin = new Vector2(0f, 1f);
        hudRt.anchorMax = new Vector2(0f, 1f);
        hudRt.pivot = new Vector2(0f, 1f);
        hudRt.sizeDelta = new Vector2(480, 110);
        hudRt.anchoredPosition = new Vector2(18, -18);

        var header = UIHelpers.CreateText(hudPanel.transform, "", 26, TextAnchor.UpperLeft);
        var hrt = header.rectTransform;
        hrt.anchorMin = new Vector2(0f, 1f);
        hrt.anchorMax = new Vector2(0f, 1f);
        hrt.pivot = new Vector2(0f, 1f);
        hrt.sizeDelta = new Vector2(460, 100);
        hrt.anchoredPosition = new Vector2(12, -10);


        var footer = UIHelpers.CreateText(canvas.transform, GetRuleString(), 18, TextAnchor.LowerCenter);
        UIHelpers.Place(footer.rectTransform, 0.5f, 0.0f, 1200, 90, new Vector2(0, 12));

        // Overlay
        var overlay = new GameObject("Overlay");
        overlay.transform.SetParent(canvas.transform, false);
        var overlayRt = overlay.AddComponent<RectTransform>();
        overlayRt.anchorMin = Vector2.zero;
        overlayRt.anchorMax = Vector2.one;
        overlayRt.offsetMin = Vector2.zero;
        overlayRt.offsetMax = Vector2.zero;

        var overlayImg = overlay.AddComponent<Image>();
        overlayImg.color = new Color(0, 0, 0, 0.75f);
        overlay.SetActive(false);

        var panel = UIHelpers.CreatePanel(overlay.transform, new Vector2(640, 360));
        UIHelpers.Place(panel.GetComponent<RectTransform>(), 0.5f, 0.5f, 640, 360);

        var title = UIHelpers.CreateText(panel.transform, "Game Over", 46, TextAnchor.MiddleCenter);
        UIHelpers.Place(title.rectTransform, 0.5f, 0.78f, 600, 90);

        var sub = UIHelpers.CreateText(panel.transform, "", 22, TextAnchor.MiddleCenter);
        UIHelpers.Place(sub.rectTransform, 0.5f, 0.60f, 600, 80);

        var playAgain = UIHelpers.CreateButton(panel.transform, "Play Again", new Vector2(220, 64));
        var prt = playAgain.GetComponent<RectTransform>();
        prt.anchorMin = new Vector2(0.5f, 0.5f);
        prt.anchorMax = new Vector2(0.5f, 0.5f);
        prt.pivot = new Vector2(0.5f, 0.5f);
        prt.anchoredPosition = new Vector2(0, -40);

        playAgain.onClick.AddListener(() => { Time.timeScale = 1f; SceneManager.LoadScene("Game"); });

        var menu = UIHelpers.CreateButton(panel.transform, "Main Menu", new Vector2(220, 64));
        var mrt = menu.GetComponent<RectTransform>();
        mrt.anchorMin = new Vector2(0.5f, 0.5f);
        mrt.anchorMax = new Vector2(0.5f, 0.5f);
        mrt.pivot = new Vector2(0.5f, 0.5f);
        mrt.anchoredPosition = new Vector2(0, -120);

        menu.onClick.AddListener(() => { Time.timeScale = 1f; SceneManager.LoadScene("MainMenu"); });

        var uiDriverGo = new GameObject("UIDriver");
        uiDriverGo.transform.SetParent(canvas.transform, false);

        var hud = uiDriverGo.AddComponent<UIHud2D>();
        hud.state = _state;
        hud.headerText = header;
        hud.overlayRoot = overlay;
        hud.overlaySubtitle = sub;
        hud.difficultyName = GameSettings.Difficulty.ToString();
    }

    private string GetRuleString()
    {
        switch (GameSettings.Difficulty)
        {
            case Difficulty.Easy:
                return "Easy: Magnet catch (normal apples). Lose 1 life per 3 misses. Endless until lives run out.";
            case Difficulty.Medium:
                return "Medium: Wind columns push apples sideways. Endless until lives run out.";
            case Difficulty.Hard:
                return "Hard: Bombs cost a life, Rotten reduces score, 2 consecutive misses freeze basket, basket shrinks on miss. Endless until lives run out.";
            default:
                return "";
        }
    }
}
