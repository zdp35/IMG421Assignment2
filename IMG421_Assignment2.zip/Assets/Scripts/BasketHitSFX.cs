using UnityEngine;

public class BasketHitSFX : MonoBehaviour
{
    private void OnCollisionEnter2D(Collision2D collision)
    {
        var apple = collision.gameObject.GetComponent<Apple2D>();
        if (apple == null) return;

        if (BasketSFX.Instance != null) BasketSFX.Instance.Play(apple.type);
    }
}
