using UnityEngine;

public enum Difficulty { Easy, Medium, Hard, Expert }

public static class GameSettings
{
    public static Difficulty Difficulty = Difficulty.Medium;

    public static DifficultyConfig GetConfig()
    {
        switch (Difficulty)
        {
case Difficulty.Easy:
                return new DifficultyConfig(
                    basketSpeed: 8.5f,
                    basketWidth: 2.6f,
                    magnetCatch: true,
                    magnetRadius: 1.35f,
                    missesPerLife: 3,
                    windEnabled: false,
                    windStrength: 0f,
                    windChaos: 0f,
                    bombsEnabled: false,
                    bombChance: 0f,
                    rottenEnabled: false,
                    rottenChance: 0f,
                    freezeOnStreakMiss: false,
                    shrinkBasketOnMiss: false,
                    spawnInterval: 0.80f,
                    spawnJitter: 0.10f,
                    fallGravityScale: 2.6f,
                    spawnerSpeed: 3.8f,
                    spawnerBounds: 8.5f
                );
case Difficulty.Medium:
                return new DifficultyConfig(
                    basketSpeed: 9.5f,
                    basketWidth: 1.9f,
                    magnetCatch: false,
                    magnetRadius: 0f,
                    missesPerLife: 1,
                    windEnabled: true,
                    windStrength: 18f,
                    windChaos: 2.5f,
                    bombsEnabled: false,
                    bombChance: 0f,
                    rottenEnabled: false,
                    rottenChance: 0f,
                    freezeOnStreakMiss: false,
                    shrinkBasketOnMiss: false,
                    spawnInterval: 0.70f,
                    spawnJitter: 0.12f,
                    fallGravityScale: 2.9f,
                    spawnerSpeed: 4.2f,
                    spawnerBounds: 8.5f
                );
case Difficulty.Hard:
                return new DifficultyConfig(
                    basketSpeed: 10.5f,
                    basketWidth: 1.9f,
                    magnetCatch: false,
                    magnetRadius: 0f,
                    missesPerLife: 1,
                    windEnabled: false,
                    windStrength: 0f,
                    windChaos: 0f,
                    bombsEnabled: true,
                    bombChance: 0.22f,
                    rottenEnabled: true,
                    rottenChance: 0.18f,
                    freezeOnStreakMiss: true,
                    shrinkBasketOnMiss: true,
                    spawnInterval: 0.36f,
                    spawnJitter: 0.08f,
                    fallGravityScale: 3.6f,
                    spawnerSpeed: 4.8f,
                    spawnerBounds: 9.5f
                );
case Difficulty.Expert:
                return new DifficultyConfig(
                    basketSpeed: 11.0f,
                    basketWidth: 1.8f,
                    magnetCatch: false,
                    magnetRadius: 0f,
                    missesPerLife: 1,
                    windEnabled: true,
                    windStrength: 22f,
                    windChaos: 8.0f,
                    bombsEnabled: true,
                    bombChance: 0.26f,
                    rottenEnabled: true,
                    rottenChance: 0.24f,
                    freezeOnStreakMiss: true,
                    shrinkBasketOnMiss: true,
                    spawnInterval: 0.30f,
                    spawnJitter: 0.10f,
                    fallGravityScale: 4.2f,
                    spawnerSpeed: 6.2f,
                    spawnerBounds: 10.5f
                );
            default:
                return new DifficultyConfig(
                    basketSpeed: 9.5f,
                    basketWidth: 1.9f,
                    magnetCatch: false,
                    magnetRadius: 0f,
                    missesPerLife: 1,
                    windEnabled: true,
                    windStrength: 18f,
                    windChaos: 2.5f,
                    bombsEnabled: false,
                    bombChance: 0f,
                    rottenEnabled: false,
                    rottenChance: 0f,
                    freezeOnStreakMiss: false,
                    shrinkBasketOnMiss: false,
                    spawnInterval: 0.70f,
                    spawnJitter: 0.12f,
                    fallGravityScale: 2.9f,
                    spawnerSpeed: 4.2f,
                    spawnerBounds: 8.5f
                );
        }
    }
}

public readonly struct DifficultyConfig
{
    public readonly float BasketSpeed;
    public readonly float BasketWidth;
    public readonly bool MagnetCatch;
    public readonly float MagnetRadius;
    public readonly int MissesPerLife;

    public readonly bool WindEnabled;
    public readonly float WindStrength;
    public readonly float WindChaos; // extra randomness (Expert)

    public readonly bool BombsEnabled;
    public readonly float BombChance;

    public readonly bool RottenEnabled;
    public readonly float RottenChance;

    public readonly bool FreezeOnStreakMiss;
    public readonly bool ShrinkBasketOnMiss;

    public readonly float SpawnInterval;
    public readonly float SpawnJitter;
    public readonly float FallGravityScale;
    public readonly float SpawnerSpeed;
    public readonly float SpawnerBounds;

    public DifficultyConfig(
        float basketSpeed,
        float basketWidth,
        bool magnetCatch,
        float magnetRadius,
        int missesPerLife,
        bool windEnabled,
        float windStrength,
        float windChaos,
        bool bombsEnabled,
        float bombChance,
        bool rottenEnabled,
        float rottenChance,
        bool freezeOnStreakMiss,
        bool shrinkBasketOnMiss,
        float spawnInterval,
        float spawnJitter,
        float fallGravityScale,
        float spawnerSpeed,
        float spawnerBounds)
    {
        BasketSpeed = basketSpeed;
        BasketWidth = basketWidth;
        MagnetCatch = magnetCatch;
        MagnetRadius = magnetRadius;
        MissesPerLife = Mathf.Max(1, missesPerLife);

        WindEnabled = windEnabled;
        WindStrength = windStrength;
        WindChaos = Mathf.Max(0f, windChaos);

        BombsEnabled = bombsEnabled;
        BombChance = Mathf.Clamp01(bombChance);

        RottenEnabled = rottenEnabled;
        RottenChance = Mathf.Clamp01(rottenChance);

        FreezeOnStreakMiss = freezeOnStreakMiss;
        ShrinkBasketOnMiss = shrinkBasketOnMiss;

        SpawnInterval = Mathf.Max(0.05f, spawnInterval);
        SpawnJitter = Mathf.Max(0f, spawnJitter);
        FallGravityScale = Mathf.Max(0.1f, fallGravityScale);
        SpawnerSpeed = Mathf.Max(0.1f, spawnerSpeed);
        SpawnerBounds = Mathf.Max(1f, spawnerBounds);
    }
}
