using UnityEngine;

public class BasketMover2D : MonoBehaviour
{
    public float speed = 9f;
    private float _freezeUntil;

    public bool IsFrozen => Time.time < _freezeUntil;

    private void Update()
    {
        if (Time.timeScale == 0f) return;

        if (IsFrozen) return;

        float targetX = transform.position.x;

        // Mouse X (WebGL-friendly)
        if (Input.mousePresent)
        {
            var wp = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            targetX = wp.x;
        }

        // Keyboard fallback
        float axis = Input.GetAxis("Horizontal");
        targetX += axis * speed * Time.deltaTime;

        targetX = Mathf.Clamp(targetX, -RuntimeTuning.BasketClamp, RuntimeTuning.BasketClamp);

        var pos = transform.position;
        pos.x = Mathf.Lerp(pos.x, targetX, 0.55f);
        transform.position = pos;
    }

    public void Freeze(float seconds)
    {
        _freezeUntil = Mathf.Max(_freezeUntil, Time.time + Mathf.Max(0.1f, seconds));
    }
}
