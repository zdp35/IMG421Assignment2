using UnityEngine;

public class BasketSFX : MonoBehaviour
{
    public static BasketSFX Instance { get; private set; }

    private AudioSource _src;
    private AudioClip _good;
    private AudioClip _bad;
    private AudioClip _bomb;

    private void Awake()
    {
        Instance = this;
        _src = GetComponent<AudioSource>();
        if (_src == null) _src = gameObject.AddComponent<AudioSource>();
        _src.playOnAwake = false;
        _src.spatialBlend = 0f;
        _src.volume = 0.8f;

        _good = Resources.Load<AudioClip>("Audio/catch_good");
        _bad  = Resources.Load<AudioClip>("Audio/catch_bad");
        _bomb = Resources.Load<AudioClip>("Audio/catch_bomb");
    }

    public void Play(AppleType type)
    {
        if (_src == null) return;

        AudioClip clip = _good;
        if (type == AppleType.Rotten) clip = _bad;
        if (type == AppleType.Bomb)   clip = _bomb;

        if (clip != null) _src.PlayOneShot(clip);
    }
}
