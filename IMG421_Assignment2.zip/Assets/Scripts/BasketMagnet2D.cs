using UnityEngine;

public class BasketMagnet2D : MonoBehaviour
{
    public float radius = 1.2f;
    public GameState state;

    private CircleCollider2D _trigger;

    private void Awake()
    {
        _trigger = gameObject.GetComponent<CircleCollider2D>();
        if (_trigger == null) _trigger = gameObject.AddComponent<CircleCollider2D>();
        _trigger.isTrigger = true;
        _trigger.radius = radius;
        _trigger.offset = new Vector2(0, 0.25f);
    }

    private void OnValidate()
    {
        if (_trigger != null) _trigger.radius = radius;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        var apple = other.GetComponent<Apple2D>();
        if (apple == null) return;

        // Only magnet NORMAL apples
        if (apple.type != AppleType.Normal) return;

        // Prevent 'pre-catch' far above the basket; only snap when close to the basket.
        if (apple.transform.position.y > transform.position.y + 0.35f) return;

        apple.SnapToBasket(transform, state);
    }
}
