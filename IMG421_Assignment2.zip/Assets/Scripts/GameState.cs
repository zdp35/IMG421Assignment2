using UnityEngine;

public class GameState
{
    public int Score { get; private set; }
    public int Lives { get; private set; }

    public bool IsGameOver { get; private set; }
    public string EndReason { get; private set; } = "You ran out of lives.";

    private int _missesPerLife;
    private int _missCounter;

    private bool _shrinkOnMiss;

    private int _consecutiveMisses;

    private int _nextStageShrinkAt = 10;

    public System.Action OnChanged;

    public GameState(int lives, int missesPerLife, bool shrinkOnMiss)
    {
        Lives = Mathf.Max(1, lives);
        _missesPerLife = Mathf.Max(1, missesPerLife);
        _shrinkOnMiss = shrinkOnMiss;
    }

    public void AddScore(int delta)
    {
        if (IsGameOver) return;

        Score += delta;
        if (Score < -10) Score = -10;

        // catching something resets miss streak
        if (delta != 0) _consecutiveMisses = 0;

        if (GameSettings.Difficulty == Difficulty.Hard && Score >= _nextStageShrinkAt)
        {
            ShrinkStage();
            _nextStageShrinkAt += 10;
        }

        OnChanged?.Invoke();
    }

    public void RegisterMiss()
    {
        if (IsGameOver) return;

        _consecutiveMisses += 1;
        _missCounter += 1;

        if (_shrinkOnMiss)
            ShrinkStage();

        if (_missCounter >= _missesPerLife)
        {
            _missCounter = 0;
            LoseLife("Too many misses.");
        }
        else
        {
            OnChanged?.Invoke();
        }

        // Hard: freeze basket on 2 consecutive misses
        if (GameSettings.Difficulty == Difficulty.Hard && _consecutiveMisses >= 2)
        {
            FreezeBasket(1.5f);
            _consecutiveMisses = 0;
        }
    }

    public void TriggerStageShrink()
    {
        // Safe public hook for hazards (e.g., Unstable Rune).
        ShrinkStage();
        OnChanged?.Invoke();
    }

    public void LoseLife(string reason)
    {
        if (IsGameOver) return;

        Lives -= 1;
        _consecutiveMisses = 0;

        if (Lives <= 0)
        {
            Lives = 0;
            IsGameOver = true;
            EndReason = reason;
        }

        OnChanged?.Invoke();
    }

    private void FreezeBasket(float seconds)
    {
        var basket = GameObject.Find("Basket");
        if (basket == null) return;
        var mover = basket.GetComponent<BasketMover2D>();
        if (mover == null) return;
        mover.Freeze(seconds);
    }

    private void ShrinkStage()
    {
        RuntimeTuning.BasketClamp = Mathf.Max(RuntimeTuning.MinClamp, RuntimeTuning.BasketClamp - 0.45f);
        // Also slightly shrink the spell circle
        ShrinkBasket();
    }

    private void ShrinkBasket()
    {
        var basket = GameObject.Find("Basket");
        if (basket == null) return;
        var s = basket.transform.localScale;
        s.x = Mathf.Max(0.35f, s.x - 0.07f);
        basket.transform.localScale = s;
    }
}
