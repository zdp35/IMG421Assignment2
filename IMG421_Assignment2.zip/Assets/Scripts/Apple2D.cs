using UnityEngine;
using System.Collections;

public enum AppleType { Normal, Bomb, Rotten }

public class Apple2D : MonoBehaviour
{
    public static float MissY = -8f;

    public AppleType type = AppleType.Normal;
    public GameState state;

    private Rigidbody2D _rb;
    private CircleCollider2D _col;
    private bool _handled;
    private float _baseScale;

    public void Init(GameState s, AppleType t)
    {
        state = s;
        type = t;

        Setup2D();
        ApplyVisual();
        AdjustHitbox();

        StartCoroutine(Pulse());
    }

    private void Setup2D()
    {
        var sr = GetComponent<SpriteRenderer>();
        if (sr == null) sr = gameObject.AddComponent<SpriteRenderer>();
        sr.sortingOrder = 2;

        _col = GetComponent<CircleCollider2D>();
        if (_col == null) _col = gameObject.AddComponent<CircleCollider2D>();
        _col.isTrigger = false;

        _rb = GetComponent<Rigidbody2D>();
        if (_rb == null) _rb = gameObject.AddComponent<Rigidbody2D>();

        _rb.gravityScale = GameSettings.GetConfig().FallGravityScale;
        _rb.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
        _rb.interpolation = RigidbodyInterpolation2D.Interpolate;
        _rb.angularDrag = 0.05f;
        _rb.drag = 0f;
    }

    private void ApplyVisual()
    {
        var sr = GetComponent<SpriteRenderer>();

        if (type == AppleType.Normal)
            sr.sprite = ArcaneFactory.ArcaneOrb(new Color(0.2f, 0.8f, 1f), new Color(0.05f, 0.4f, 1f), 0f);

        if (type == AppleType.Bomb)
            sr.sprite = ArcaneFactory.ArcaneOrb(new Color(0.8f, 0.1f, 0.1f), new Color(0.4f, 0.0f, 0.0f), 1f);

        if (type == AppleType.Rotten)
            sr.sprite = ArcaneFactory.ArcaneOrb(new Color(0.6f, 0.3f, 0.8f), new Color(0.2f, 0.05f, 0.4f), 2f);

        _baseScale = (type == AppleType.Bomb) ? 0.52f : 0.58f;
        transform.localScale = Vector3.one * _baseScale;
    }

    private void AdjustHitbox()
    {
        if (_col == null) return;
        float s = Mathf.Max(0.1f, transform.localScale.x);
        _col.radius = 0.55f * s;
    }

    private IEnumerator Pulse()
    {
        var sr = GetComponent<SpriteRenderer>();
        float t = Random.value * 10f;

        while (true)
        {
            t += Time.deltaTime * 3.2f;

            float pulse = 1f + 0.035f * Mathf.Sin(t);
            transform.localScale = Vector3.one * (_baseScale * pulse);

            float aPulse = 0.90f + 0.10f * Mathf.Sin(t + 1.7f);
            sr.color = new Color(1f, 1f, 1f, aPulse);

            yield return null;
        }
    }

    private void Update()
    {
        if (_handled) return;

        if (transform.position.y < MissY)
        {
            HandleMiss();
        }
    }

    private void OnBecameInvisible()
    {
        if (_handled) return;

        // Only treat as miss if it left the camera below the miss line.
        if (transform.position.y < MissY)
        {
            HandleMiss();
        }
    }

    private void HandleMiss()
    {
        _handled = true;

        // Only blue orbs count as misses.
        if (type == AppleType.Normal)
            state.RegisterMiss();

        Destroy(gameObject);
    }

    public void SnapToBasket(Transform basket, GameState s)
    {
        if (_handled) return;
        _handled = true;

        // Sound on magnet catch
        if (BasketSFX.Instance != null) BasketSFX.Instance.Play(type);

        if (_rb != null)
        {
            _rb.velocity = Vector2.zero;
            _rb.isKinematic = true;
            _rb.simulated = false;
        }

        transform.position = basket.position + new Vector3(0, 0.85f, 0);

        if (type == AppleType.Normal) s.AddScore(1);

        Destroy(gameObject);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (_handled) return;

        if (collision.gameObject.name == "Basket")
        {
            _handled = true;

            // Sound on physical catch
            if (BasketSFX.Instance != null) BasketSFX.Instance.Play(type);

            if (type == AppleType.Normal)
                state.AddScore(1);
            else if (type == AppleType.Rotten)
            {
                state.AddScore(-1);
                if (GameSettings.Difficulty == Difficulty.Hard)
                    state.TriggerStageShrink();
            }
            else if (type == AppleType.Bomb)
                state.LoseLife("Void Fragment destabilized the ritual!");

            Destroy(gameObject);
        }
    }
}
